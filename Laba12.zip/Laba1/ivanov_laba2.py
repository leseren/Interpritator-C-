import string
import re
import random
import operator
import numpy as np
import copy
import itertools

# составляет список всех символов, используемых в тексте
def find_symbol(text):
    file = open(text, 'r', encoding='utf-8');
    all_symbols = []

    for line in file.readlines():
        for s in line:
            if s not in all_symbols:
                all_symbols.append(s)

    file.close()
    return all_symbols
    

# печать словаря (таблицы)
def all_text(filename):
    f = open(filename, 'r')
    string = ''
    for line in f:
        string += line
    return string

# изменения текста (удаление пробелов, переносов, цифр, пунктуации, приведение к большим и маленьким буквам)
# возвращает имя нового файла, в котором находятся все внесенные изменения
def delete_symbol(text, result, characters):
    file = open(text, 'r', encoding='utf-8');
    fileResult = open(result, 'w', encoding='utf-8');
    for line in file.readlines():
        line = line.replace('\n', ' ');
        line = line.lower();
        #line = line.replace(' ', '');
        
        for s in line:
            if s in string.punctuation:
                line = line.replace(s, '');
            if s.isdigit():
                line = line.replace(s, '');

        if characters != None:
            for s in line:
                if s in characters:
                    line = line.replace(s, '');

        fileResult.write(line);
    file.close();
    fileResult.close();

# Пункт 2. создание таблицы пользователем самостоятельно: [cipher char]: char
def create_map_user(all_chars, chars_for_cipher, cipher_map_user):
    for ch in all_chars:
        print('доступные символы для зашифрования: ', chars_for_cipher)
        print('введите символ зашифрованного алфавита для символа ', ch)
        cipher_ch = str(input())

        cipher_map_user.setdefault(cipher_ch, 0)
        cipher_map_user[cipher_ch] = ch

        chars_for_cipher.remove(cipher_ch)

# Пункт 2. создание таблицы автоматически 
def create_map_auto(all_chars, chars_for_cipher, cipher_map_auto):
    print('all chars: ', all_chars)
    
    #n = 3
    #chars_for_cipher = chars_for_cipher[n:] + chars_for_cipher[:n]

    random.shuffle(chars_for_cipher)

    for i in range(len(all_chars)):
        cipher_map_auto.setdefault(all_chars[i], 0)
        cipher_map_auto[all_chars[i]] = chars_for_cipher[i]
        # ключ - символ открытого текста, знаечние - шифрованный символ

# Пункт 3. Шифрование открытого текста с использованием таблицы, 
# возвращает имя файла, в котором находится шифр
def encryption(filename, cipher_text_name, cipher_map_user, cipher_map_auto):
    f1 = open(filename, 'r', encoding='utf-8')
    f2 = open(cipher_text_name, 'w', encoding='utf-8')

    for line in f1.readlines():
        for ch in line:
            f2.write(cipher_map_auto[ch]) # подставляю под каждый символ открытого текста соответствующий ему символ шифра

    f1.close()
    f2.close()


# Пункт 4. Расшифрование шифротекста с использованием ключа шифрования
def decryption_with_key(filename, cipher_map_user, cipher_map_auto):
    f1 = open(filename, 'r', encoding='utf-8')
    f2 = open('C:/Users/fakel/Desktop/Laba1/decryption_with_key.txt', 'w', encoding='utf-8')

    for line in f1.readlines():
        for ch in line:
            f2.write(list(cipher_map_auto.keys())[list(cipher_map_auto.values()).index(ch)])

    f1.close()
    f2.close()

# поиск всех k-грамм и m-грамм, где m = 1..k, в данном случае k=2, m=1
def count_k_grams(filename, k):
    f = open(filename, 'r', encoding='utf-8')
    all_grams = {}
    counts = []
    probs = {}

    mono_grams = {}
    k_grams = {}

    for line in f.readlines():
        for i in range(len(line)):
            m = 1
            while m <= k and i + m <= len(line):
                g = line[i:i+m]
                all_grams.setdefault(g, 0)
                all_grams[g] += 1
                m += 1

    for i in range(0, k + 1):
        counts.append(0)

    for key in all_grams.keys():
        counts[len(key)] += all_grams[key]

    for key in all_grams.keys():
        probs.setdefault(key, 0)
        probs[key] = all_grams[key] / counts[len(key)]

    for key in probs.keys():
        if len(key) == k:
            k_grams.setdefault(key, 0)
            k_grams[key] = probs[key]
        if len(key) == 1:
            mono_grams.setdefault(key, 0)
            mono_grams[key] = probs[key]

    f.close()

    return mono_grams, k_grams

# находит частоту биграммы 'xy', получая на вход символы x и y
def find_bigram_prob(letter1, letter2, k_grams):
    for key in k_grams.keys():
        if key[0] == letter1 and key[1] == letter2:
            return k_grams[key]
    return 0

# создает матрицу биграм, получая на вход символы с частотами и биграммы с частотами
def create_bigram_matrix(mgrams, bigrams):
    m = [[0.0 for j in range(len(mgrams))] for i in range(len(mgrams))]

    for i in range(len(mgrams)):
        for j in range(len(mgrams)):
            m[i][j] = find_bigram_prob(list(mgrams.keys())[i], list(mgrams.keys())[j], bigrams)

    return m

# bi_cipher - матрица биграмм, полученных из зашифрованного текста
# bi_open - матрица биграмм открытого текста
def mera(bi_cipher, bi_open):
    s = 0

    for i in range(len(bi_cipher)):
        for j in range(len(bi_cipher)):
            s += abs(bi_cipher[i][j] - bi_open[i][j])
    
    return s

# 1 первоначальный вариант ключа, сопоставляем символы
def first_key(m_grams_open, cipher_text_filename):
    key = {}
    m_grams_cipher, k_grams_cipher = count_k_grams(cipher_text_filename, 2) # символы и биграммы шифрованного текста

    for k1 in m_grams_cipher.keys(): # проход по символвам шифра
        min_diff = 1
        for k2 in m_grams_open.keys(): # по символам открытого
            key.setdefault(k1, 0)
            if abs(m_grams_cipher[k1] - m_grams_open[k2]) < min_diff:
                min_diff = abs(m_grams_cipher[k1] - m_grams_open[k2])
                key[k1] = k2 # здесь записывается соответствие символов зашифрованного текста к символам открытого

    key1 = [[],[]]
    key1[0] = list(key.values()) # открытые символы 
    key1[1] = list(key.keys()) # зашифрованные символы

    return key, key1

# меняет местами символы в ключе и возвращает эти символы
def key_transposition(key1):    
    random.seed(len(key1)-1)
    ind1 = random.randint(0, len(key1)-len(key1)/2)
    ind2 = random.randint(ind1, len(key1)-1)

    char1 = list(key1)[ind1]
    char2 = list(key1)[ind2]

    key1[char1], key1[char2] = key1[char2], key1[char1]

    return char1, char2

# меняем строки и столбцы местами
def matrix_transposition(Dk, mgrams, ch1, ch2):
    ind1, ind2 = 0, 0
    for i in range(len(mgrams)):
        if list(mgrams.keys())[i] == ch1:
            ind1 = i
        if list(mgrams.keys())[i] == ch2:
            ind2 = i

    Dk_new = copy.deepcopy(Dk)
    Dk_new[ind1], Dk_new[ind2] = Dk_new[ind2], Dk_new[ind1]
    Dk_new[ind1][ind1], Dk_new[ind1][ind2] = Dk_new[ind1][ind2], Dk_new[ind1][ind1]
    Dk_new[ind2][ind1], Dk_new[ind2][ind2] = Dk_new[ind2][ind2], Dk_new[ind2][ind1]

    return Dk_new

# Пункт 5. Криптоанализ (дешифрование) шифротекста без  использования ключа  шифрования
def cryptanalysis(open_text_filename, cipher_text_filename):
    flag_end = False # флаг окончания алгоритма
    it = 0 # счетчик, сколько условие не выполняется
    new_text_name = 'C:/Users/fakel/Desktop/Laba1/without_key.txt'
    f = open(cipher_text_filename, 'r', encoding='utf-8')
    f2 = open(new_text_name, 'w', encoding='utf-8')

    m_grams_open, k_grams_open = count_k_grams(open_text_filename, 2) # символы и биграммы открытого текста
    bigram_matrix_open = create_bigram_matrix(m_grams_open, k_grams_open) # формирование матрицы биграмм открытого текста

    key, _  = first_key(m_grams_open, cipher_text_filename) # первый ключ 

    for line in f.readlines():
        for ch in line:
            f2.write(key[ch])

    f2.close()

    # ПУНКТ 2  строим для текста матрицу биграм 
    first_mgrams, first_bigrams = count_k_grams(new_text_name, 2)
    Dk = create_bigram_matrix(first_mgrams, first_bigrams)
    first_mera = mera(Dk, bigram_matrix_open)
    
    min_mera = copy.deepcopy(first_mera)

    for i in range(1000):
        if flag_end == True:
            break

        key1 = copy.deepcopy(key) # ПУНКТ 3

        while True:
            new_text = open(new_text_name, 'w', encoding='utf-8')
            f.seek(0)

            ch1, ch2 = key_transposition(key1) # ПУНКТ 4  поменять ключ key1
            Dk_new = matrix_transposition(Dk, first_mgrams, ch1, ch2) # ПУНКТ 5  меняем местами строки a b и столбцы с номерами a b, это будет новая матрица Dk_new

            current_mera = mera(Dk_new, bigram_matrix_open) # ПУНКТ 6  сравниваем полученную матрицу с матрицей открытого текста

            if current_mera < min_mera:
                key = copy.deepcopy(key1)
                current_mera = min_mera
                new_text.close()
            else:
                it += 1 # считаем, сколько раз условие не выполняется
                if it >= 100: 
                    flag_end = True
                break
        
        
        new_text.close()

    # расшифровываем текст финальным ключом
    new_text = open(new_text_name, 'w', encoding='utf-8')

    for line in f.readlines():
        for ch in line:
            new_text.write(key1[ch])

    f.close()
    new_text.close()

def main():

    file_name = 'C:/Users/fakel/Desktop/Laba1/text.txt'
    file_result = 'C:/Users/fakel/Desktop/Laba1/file_result.txt'
    another_open_text_name = 'C:/Users/fakel/Desktop/Laba1/second_text.txt'
    print('Все символы используемые в тексте: ', find_symbol(file_name));
    
    # пункт 1. удаление символов из текста

    str = ['«','„', '“', '»', '–', '—','\xa0', '…', 'n', '́'];
    delete_symbol(file_name, file_result, str);
    
    all_chars = find_symbol(file_result)
    chars_for_cipher = find_symbol(file_result)

    # пункт 2. создать таблицу
    
    cipher_map_user = {}
    cipher_map_auto = {}
    #create_map_user(all_chars, chars_for_cipher, cipher_map_user)
    create_map_auto(all_chars, chars_for_cipher, cipher_map_auto)

    # пункт 3. шифрование текста ключом
    cipher_text_name = 'C:/Users/fakel/Desktop/Laba1/cipher_text.txt';
    encryption(file_result, cipher_text_name, cipher_map_user, cipher_map_auto)

    # пункт 4. расшифрование с помощью ключа
    decryption_with_key(cipher_text_name, cipher_map_user, cipher_map_auto)

    # пункт 5. дешифрование без ключа
    file_result2 = 'C:/Users/fakel/Desktop/Laba1/file_result2.txt'
    delete_symbol(another_open_text_name, file_result2, str) # удалим из "тренировочного" текста пунктуацию и цифры
    print(find_symbol(file_result2));
    cryptanalysis(file_result, cipher_text_name)
    print('Ok');

main()
