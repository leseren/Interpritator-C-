# Иванов Сергей. Лаба 1
import codecs
import string
import random

#Составляем список всех элементов, используемых в тексте
def list_symbol(text):
    file = open(text, 'r');
    allSymbol=[];
    
    for line in file.readlines():
        for i in line:
            if i not in allSymbol:
                allSymbol.append(i);

    file.close();
    print("Все символы в документе", allSymbol)
    return allSymbol;

#Удаление знаков препинания, пробелов, цифры.
#Объединение маленьких или больших букв.
def delete_symbol(text, textRes, flag_punct, flag_spaces, flag_numbers, flag_lower, flag_upper, characters):
    file = open(text, 'r');
    fileResult = open(textRes, 'w');
    
    for line in file.readlines():
        line = line.replace('\n', ' ');

        if flag_punct:
            for s in line:
                if s in string.punctuation:
                    line = line.replace(s, '');
        if flag_spaces:
            line = line.replace(' ', '');
        if flag_numbers:
            for s in line:
                if s.isdigit():
                    line = line.replace(s, '');
        if flag_lower:
            line = line.lower();         
        if flag_upper:
            line = line.upper();   
        if characters != None:
            for s in line:
                if s in characters:
                    line = line.replace(s, '');

        fileResult.write(line);
        
    file.close();
    fileResult.close();
 

#Поиск всех m-грамм и их сохраение.
def keep_all_m_gramm(textRes, allGramms, k):
    fileRes = open(textRes);
    
    for line in fileRes.readlines():
        for i in range(len(line)):
            m = 1;
            while i+m <= len(line) and m <= k:
                f = line[i:i+m];
                allGramms.setdefault(f, 0);
                allGramms[f] += 1;
                m += 1;
                
    fileRes.close();

#Нахождение вероятностей всех m-грамм в тексте.
def probability_m_gramm(allGramms, count, probs, k):
    for i in range(0, k+1):
        count.append(0);

    for key in allGramms.keys():
        count[len(key)] += allGramms[key];

    for key in allGramms.keys():
        probs.setdefault(key, 0);
        probs[key] = allGramms[key]/count[len(key)];

#Формирование набора - k-грамма : вероятность.
def count_k_gramm(kGramms, probs, k):
    for key in probs.keys():
        if len(key) == k:
            kGramms.setdefault(key, 0);
            kGramms[key] = probs[key];

#Печать всех k-грамм
def print_gramms(d):
    print('Все k-граммы: ');
    for i in d:
        print(' ', i, ' x ', d[i], sep = '');

#Создание текста
def create_text(textNew, kGramms):
    fileNew = open(textNew, 'w');
    kgr = list(kGramms.keys())[0];
    fileNew.write(kgr);

    print('Количество k-грамм', len(kGramms));
    #Печать к-грамм с их вероятностями.
    #print_gramms(kGramms);
        
    for i in range(1000):
        newChar = '';
        kgr = kgr[1:len(kgr)];
        characters = [];

        for gram in kGramms.keys():
            if gram[:len(gram)-1] == kgr: 
                characters.append([kGramms[gram], gram[len(gram)-1]]);

        characters.sort();

        for i in range(1, len(characters)):
            characters[i][0] += characters[i-1][0];

        x = random.uniform(0, characters[len(characters)-1][0]);
        #print(x);
        for i in characters:
           if i[0] >= x :
                newChar = i[1];
                break;

        if newChar == '':
            newChar = characters[len(characters)-1][1];
           
        fileNew.write(kgr);
        print(newChar, end="");
        kgr += newChar;

    fileNew.close();
    
#Вызов функций
def call(file1, file2, file3):
    list_symbol(file1);
    print("Чтобы следующие действия выполнились в программе, ответьте на вопросы +(да), Enter(нет)");
    a = input("Удалить все знаки препинания? \n");
    b = input("Удалить все пробелы? \n");
    c = input("Удалить все цифры? \n");
    d = input("Поменять регистр букв на нижний? \n");
    e = input("Поменять регистр букв на верхний? \n");
    f = input("Напишите символы, которые хотите удалить? В противном случае нажмите Enter. \n");
    k =int(input("Введите k: \n"));
    delete_symbol(file1, file2, a, b, c, d, e, f);

    allGramms = {};
    keep_all_m_gramm(file2, allGramms, k);

    count = [];
    probs = {};
    probability_m_gramm(allGramms, count, probs, k);

    kGramms = {}; #содрежит все к-граммы размера к и их вероятности
    count_k_gramm(kGramms, probs, k); #подсчет всех k-грамм размера k

    create_text(file3, kGramms);
    
def main():

    print("1. Гоголь. Мертвые души. \n 2. Джулия Эндерс. Очаровательный кишечник. \n 3. Оба варианта текста \n Введите цифру варианта:");
    var = int(input());
    if var == 1:
        call("C:/Users/fakel/Desktop/Laba1/text_lit.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_res.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_new.txt");
    elif var == 2:
        call("C:/Users/fakel/Desktop/Laba1/text_sci.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_res.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_new.txt");
    elif var == 3:
        call("C:/Users/fakel/Desktop/Laba1/text_lit.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_res.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_new.txt");
        call("C:/Users/fakel/Desktop/Laba1/text_sci.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_res.txt", "C:/Users/fakel/Desktop/Laba1/text_lit_new.txt");
    else:
        print("ERROR");

main();
